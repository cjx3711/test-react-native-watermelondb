import React, { Component, Fragment } from 'react';
import { Container, Header, Title, Content, Footer, FooterTab, Button, Left, Right, Body, Icon, Text, ListItem, CheckBox, Col, Grid } from 'native-base';
import { Q } from '@nozbe/watermelondb';
import { Alert } from 'react-native';
export default class AnatomyExample extends Component {
  constructor(props) {
    super(props)
    console.log("App Constructor")
    // console.log(props)
    const database = props.database;
    const tasksCollection = database.get('tasks')

    const updatePage = async() => {
      // const tasksCollection = this.props.database.get('tasks')
      console.log("Fetching task count")
      const taskCount = await tasksCollection.query().fetchCount()
      const tasks = await tasksCollection.query()
      console.log("Tasks count", taskCount)
      this.setState({taskCount: taskCount, tasks: tasks})
    }
    updatePage()

    const add = async() => {
      await database.action(async () => {
        const newTask = await tasksCollection.create(task => {
          task.description = 'New task'
          task.isComplete = false
        })
        console.log("Adding new task")
      })
      console.log("Added new task")
    }
    // add()

    this.state = {
      taskCount: 0,
      tasks: []
    }
  }

  // async updatePage() {
  //   const tasksCollection = this.props.database.get('tasks')
  //   console.log("Fetching task count")
  //   const taskCount = await tasksCollection.query().fetchCount()
  //   const tasks = await tasksCollection.query()
  //   console.log("Tasks count", taskCount)
  //   this.setState({taskCount: taskCount, tasks: tasks})
  // }

  // setChecked(task) {
  //   (async () => {
  //     console.log("Setting checked", task.id)
  //     await task.check()
  //     // this.updatePage()
  //   })()
  // }

  render() {
    return (
      <Container>
        <Header>
          <Left>
            <Button transparent>
              <Icon name='menu' />
            </Button>
          </Left>
          <Body>
            <Title>Header</Title>
          </Body>
          <Right />
        </Header>
        <Content padder>
          <Text>
            There are { this.state.taskCount } tasks
          </Text>
          <Fragment>
          {
            this.state.tasks.map((m, i) => {
              return (
                <ListItem key={m.id}>
                  <CheckBox checked={m.isComplete} onPress={() => alert("Clicked check")}/>
                  <Body>
                    <Grid>
                      <Col style={{width: '60%'}}>
                        <Text>{m.description}</Text>
                      </Col>
                      <Col>
                        <Button block rounded onPress={() => alert("Clicked on thing")}>
                          <Text>Subtasks</Text>
                        </Button>
                      </Col>
                    </Grid>
                  </Body>
                </ListItem>
              )
            })
          }
          </Fragment>
          
        </Content>
        <Footer>
          <FooterTab>
            <Button full>
              <Text>Add Task</Text>
            </Button>
          </FooterTab>
        </Footer>
      </Container>
    );
  }
}